<?php
// Include database connection
include_once 'config.php';

// Check if the motor ID is provided in the query parameter
if(isset($_GET['motor_id'])) {
    // Sanitize the input to prevent SQL injection
    $motorId = intval($_GET['motor_id']);

    // Prepare a DELETE statement
    $sql = "DELETE FROM Motors WHERE motor_id = ?";

    // Bind the motor ID parameter to the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $motorId);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect back to the page where the deletion was initiated
        header("Location: ".$_SERVER["HTTP_REFERER"]);
        exit();
    } else {
        echo "Error deleting motor: " . $conn->error;
    }
} else {
    // If motor ID is not provided, display an error message
    echo "Motor ID not provided.";
}
?>
