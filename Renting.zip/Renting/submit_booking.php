<?php
// Include database configuration file
include_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $motorBrand = $_POST['brand'];
    $additionalItems = isset($_POST['additionalItems']) ? implode(',', $_POST['additionalItems']) : '';
    $date = $_POST['date'];
    $numDays = $_POST['days'];
    $totalPrice = $_POST['total'];

    // Insert data into the database
    $sql = "INSERT INTO bookings (motor_brand, additional_items, date, num_days, total_price) VALUES ('$motorBrand', '$additionalItems', '$date', '$numDays', '$totalPrice')";

    if ($conn->query($sql) === TRUE) {
        echo "Booking submitted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close database connection
    $conn->close();
}

?>
