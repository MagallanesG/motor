<?php
include 'config.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define variables and set to empty values
$motorBrand = $date = $numDays = $totalPrice = "";
$additionalItemName = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $motorBrand = $_POST['motorBrand'];
    $additionalItemName = isset($_POST['additionalItems']) ? 'helmet' : '';
    $date = $_POST['dateChooser'];
    $numDays = $_POST['numDays'];
    $totalPrice = $_POST['totalPrice'];

    // Insert data into bookings table
    $sql = "INSERT INTO bookings (motor_brand, additional_items, date, num_days, total_price, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssidd", $motorBrand, $additionalItemName, $date, $numDays, $totalPrice);
    if ($stmt->execute()) {
        echo "Booking saved successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
}

// Close the database connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>

    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="number"],
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Booking Form</h2>
        <form id="bookingForm" method="POST">
            <div class="form-group">
                <label for="motorBrand">Motor Brand:</label>
                <select id="motorBrand" name="motorBrand">
                    <option value="">Choose a Motor Brand</option>
                    <?php
                    foreach ($motorBrandPrices as $brand => $price) {
                        echo "<option value='$brand' data-price='$price'>$brand</option>";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="additionalItems">Additional Helmet:</label>
                <input type="checkbox" id="additionalItems" name="additionalItems"> Yes
            </div>
            <div class="form-group">
                <label for="dateChooser">Choose Date:</label>
                <input type="date" id="dateChooser" name="dateChooser">
            </div>
            <div class="form-group">
                <label for="numDays">Number of Days:</label>
                <input type="number" id="numDays" name="numDays" min="1">
            </div>
            <div class="form-group">
                <label for="totalPrice">Total Price:</label>
                <input type="text" id="totalPrice" name="totalPrice" readonly>
            </div>
            <button type="submit">Submit</button>
        </form>
    </div>

    <script>
        function updateTotalPrice() {
            var motorBrandSelect = document.getElementById('motorBrand');
            var selectedOption = motorBrandSelect.options[motorBrandSelect.selectedIndex];
            var motorBrandPrice = parseFloat(selectedOption.getAttribute('data-price'));
            
            var additionalItemPrice = document.getElementById('additionalItems').checked ? <?php echo $additionalItemPrice; ?> : 0;

            var numDays = parseInt(document.getElementById('numDays').value);

            var totalPrice = motorBrandPrice + additionalItemPrice;

            if (!isNaN(numDays) && numDays > 0) {
                totalPrice *= numDays;
            }

            document.getElementById('totalPrice').value = totalPrice.toFixed(2);
        }

        document.getElementById('motorBrand').addEventListener('change', updateTotalPrice);
        document.getElementById('additionalItems').addEventListener('change', updateTotalPrice);

        updateTotalPrice();
    </script>
</body>
</html>
