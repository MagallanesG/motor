<?php
include_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Input validation
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);
    $confirm_password = filter_input(INPUT_POST, 'confirm_password', FILTER_SANITIZE_STRING);
    $first_name = filter_input(INPUT_POST, 'first_name', FILTER_SANITIZE_STRING);
    $last_name = filter_input(INPUT_POST, 'last_name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $phone_number = filter_input(INPUT_POST, 'phone_number', FILTER_SANITIZE_STRING);
    $date_of_birth = filter_input(INPUT_POST, 'date_of_birth', FILTER_SANITIZE_STRING);

    // Validate required fields
    if (!$username || !$password || !$confirm_password || !$first_name || !$last_name || !$email || !$phone_number || !$date_of_birth) {
        echo "All fields are required!";
        exit;
    }

    // Validate password
    if ($password !== $confirm_password) {
        echo "Passwords do not match!";
        exit;
    }

    // Hash the password
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // Check database connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    try {
        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO Users (Username, PasswordHash, FirstName, LastName, Email, PhoneNumber, DateOfBirth) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $username, $password_hash, $first_name, $last_name, $email, $phone_number, $date_of_birth);

        // Execute the statement
        $stmt->execute();

        // Redirect user to index.html after successful sign-up
        header("Location: index.html");
        exit;
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 23000) {
            echo "Username or Email already exists!";
        } else {
            echo "Error: " . $e->getMessage();
        }
    } finally {
        // Close the statement
        $stmt->close();
        // Close the connection
        $conn->close();
    }
}
?>
