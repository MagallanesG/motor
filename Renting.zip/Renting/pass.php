<?php
// Replace 'your_password_here' with the actual password you want to hash
$password = 'admin123';

// Hash the password
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

// Output the hashed password
echo $passwordHash;
?>
