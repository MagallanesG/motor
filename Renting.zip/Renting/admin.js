// Function to display the overlay
function addFunction() {
    var overlay = document.getElementById('overlay');
    overlay.style.display = 'flex';
}

// Function to close the overlay
function closeOverlay() {
    var overlay = document.getElementById('overlay');
    overlay.style.display = 'none';
}

function deleteFunction(motorId) {
    // Confirm with the user before deleting
    if (confirm("Are you sure you want to delete this motor?")) {
        // Assuming you have a PHP script called delete_motor.php to handle the deletion
        // You need to pass the motor ID to this script

        // Redirect to the delete_motor.php script with the motor ID as a query parameter
        window.location.href = 'delete_motor.php?motor_id=' + motorId;
    }
}

function viewFunction(motorId) {
    // Confirm with the user before deleting
    
        // Assuming you have a PHP script called delete_motor.php to handle the deletion
        // You need to pass the motor ID to this script

        // Redirect to the delete_motor.php script with the motor ID as a query parameter
        window.location.href = 'view_motor.php?motor_id=' + motorId;
    }

    function updateFunction(motorId) {
        // Assuming motorId is passed as an argument
        // You can perform any update-related actions here
        console.log("Updating motor with ID: " + motorId);
        // Add your update logic here, such as making an AJAX request or redirecting to an update page
        // For example, you can redirect to an update page passing the motor ID as a query parameter:
        window.location.href = "update_motor.php?id=" + motorId;
    }
    

// Function to open the overlay for adding additional item
function openAddAdditionalForm() {
    document.getElementById("additionalOverlay").style.display = "flex";
}

// Function to close the overlay for adding additional item
function closeAdditionalOverlay() {
    document.getElementById("additionalOverlay").style.display = "none";
}

// Function to view additional items
function viewAdditionalItems() {
    // You can implement the functionality to view additional items here
    // For example, redirecting to a new page or displaying a modal with additional items
    // Replace this alert with your actual implementation
    alert("Viewing additional items");
}


function toggleMotor(motorId) {
    var row = document.getElementById('motorRow_' + motorId);
    if (row) {
        // Send an AJAX request to toggle the motor's status
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Update the row's appearance based on the response
                    row.classList.toggle('disabled-row');
                } else {
                    // Handle errors
                    console.error('Failed to toggle motor status.');
                }
            }
        };
        xhr.open('POST', 'toggle_motor.php', true); // Send request to toggle_motor.php
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send('motor_id=' + motorId + '&action=toggle');
    }
}



