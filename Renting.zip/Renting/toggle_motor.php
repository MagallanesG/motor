<?php
// Include database connection
include_once 'config.php';

// Check if a motor ID and action are provided
if (isset($_POST['motor_id']) && isset($_POST['action'])) {
    $motorId = $_POST['motor_id'];
    $action = $_POST['action'];
    
    // Update the status of the motor in the database
    if ($action === 'toggle') {
        // Toggle the enabled status
        $sql = "UPDATE Motors SET enabled = NOT enabled WHERE motor_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $motorId);
        $stmt->execute();
        $stmt->close();
    }
}
?>
