const navbarMenu = document.querySelector(".navbar .links");
const hamburgerBtn = document.querySelector(".hamburger-btn");
const hideMenuBtn = navbarMenu.querySelector(".close-btn");
const showPopupBtns = document.querySelectorAll(".login-btn, .button, .button1, .button2"); // Include all relevant buttons
const formPopup = document.querySelector(".form-popup");
const hidePopupBtn = document.querySelector(".form-popup .close-btn"); // Select the close button inside the form popup
const signupLoginLink = formPopup.querySelectorAll(".bottom-link a");

// Show mobile menu
hamburgerBtn.addEventListener("click", () => {
    navbarMenu.classList.toggle("show-menu");
});

// Hide mobile menu
hideMenuBtn.addEventListener("click", () =>  hamburgerBtn.click());

// Show login popup
showPopupBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        document.body.classList.toggle("show-popup");
    });
});

// Hide login popup
hidePopupBtn.addEventListener("click", () => {
    document.body.classList.remove("show-popup"); // Remove the "show-popup" class from the body
});

// Show or hide signup form
signupLoginLink.forEach(link => {
    link.addEventListener("click", (e) => {
        e.preventDefault();
        formPopup.classList.toggle("show-signup");
    });
});

// Function to handle AJAX response and redirect to user.html
function handleSignUpResponse(response) {
    if (response.success) {
        // Redirect user to user.html
        window.location.href = "user.html";
    } else {
        // Log error message if sign-up failed
        console.error("Error:", response.error);
    }
}








/*--------------------------------*/




document.addEventListener("DOMContentLoaded", function() {
    var paragraph = document.querySelector(".paragraph");
    paragraph.classList.add("reveal"); // Add the 'reveal' class
});

document.addEventListener("DOMContentLoaded", function() {
    var paragraph1 = document.querySelector(".paragraph1");
    paragraph1.classList.add("reveal"); // Add the 'reveal' class
});

document.addEventListener("DOMContentLoaded", function() {
    var btn3 = document.querySelector(".btn3");
    btn3.classList.add("reveal"); // Add the 'reveal' class
});


document.addEventListener("DOMContentLoaded", function() {
    var img = document.querySelector(".img");
    img.classList.add("reveal"); // Add the 'reveal' class to trigger the animation
});


window.addEventListener('scroll', function() {
    var scrollPosition = window.scrollY;
    var navbar = document.querySelector('.navbar');

    // Add or remove the 'scrolled' class based on scroll position
    if (scrollPosition > 0) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }

    // Change text color based on scroll position with a transition effect
    var navbarLinks = document.querySelectorAll('.navbar .links a');
    var textColor = scrollPosition > 0 ? 'white' : 'black';
    navbarLinks.forEach(function(link) {
        link.style.transition = 'color 0.3s ease'; // Add transition effect
        link.style.color = textColor;
    });
});


  