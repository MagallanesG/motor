

<?php
// Include database connection
include_once 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['additional_name'];
    $price = $_POST['additional_price']; // Corrected variable name

    // Prepare SQL statement to insert data into the AdditionalItems table
    $sql = "INSERT INTO AdditionalItems (name, additional_price) VALUES (?, ?)";
    
    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sd", $name, $price); // Corrected variable name

    // Execute the statement
    if ($stmt->execute()) {
        // Insertion successful
        echo "Additional item added successfully.";
    } else {
        // Insertion failed
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close statement
    $stmt->close();
}

// Close connection
$conn->close();
?>
