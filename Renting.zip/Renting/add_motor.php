<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    include_once 'config.php';
    
    // Prepare and bind parameters
    $stmt = $conn->prepare("INSERT INTO Motors (brand, driver_firstname, driver_lastname, address, price, img_path_for_motor, img_path_for_user) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssdss", $brand, $driver_firstname, $driver_lastname, $address, $price, $img_path_for_motor, $img_path_for_user);

    // Set parameters
    $brand = $_POST['brand'];
    $driver_firstname = $_POST['driver_firstname'];
    $driver_lastname = $_POST['driver_lastname'];
    $address = $_POST['address'];
    $price = $_POST['price'];
  
    // File upload handling for motor image
    $img_path_for_motor = '';
    if (isset($_FILES['img_path_for_motor']) && $_FILES['img_path_for_motor']['error'] === UPLOAD_ERR_OK) {
        $img_path_for_motor = $_FILES['img_path_for_motor']['name'];
        move_uploaded_file($_FILES['img_path_for_motor']['tmp_name'], 'uploads/' . $img_path_for_motor);
    }
    
    // File upload handling for user image
    $img_path_for_user = '';
    if (isset($_FILES['img_path_for_user']) && $_FILES['img_path_for_user']['error'] === UPLOAD_ERR_OK) {
        $img_path_for_user = $_FILES['img_path_for_user']['name'];
        move_uploaded_file($_FILES['img_path_for_user']['tmp_name'], 'uploads/' . $img_path_for_user);
    }

    // Execute the statement
    if ($stmt->execute()) {
        echo "New motor added successfully.";
        
        // Display the uploaded images
        if (!empty($motor_image)) {
            echo "<p>Motor Image: <img src='uploads/$motor_image' alt=''></p>";
        }
        if (!empty($user_image)) {
            echo "<p>User Image: <img src='uploads/$user_image' alt=''></p>";
        }
    } else {
        echo "Error: " . $conn->error;
    }

    // Close statement and database connection
    $stmt->close();
    $conn->close();
}
?>
