<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="motor.css">

   <!-- custom js file link  -->
   <script src="motor.js" defer></script>

   <style>
    /* Additional styles for the booking form */
    .booking-form {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: grey;
        width: 50%;
        height: 70%;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        padding: 20px; /* Added padding to the form */
    }

    /* Target labels within the booking form */
    .booking-form label {
        margin-bottom: 10px; /* Adjust the margin as needed */
        margin-right: 30px;
    }
</style>


</head>
<body>
   
<div class="container">

   <h3 class="title"> organic products </h3>

   <div class="products-container">
   <?php
    // Include database connection
    include_once 'config.php';

    // Fetch motor data from the database where enabled is 1 (enabled)
    $sql = "SELECT * FROM Motors WHERE enabled = 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            ?>
            <!-- Check if the motor is enabled -->
            <?php if ($row['enabled'] == 1): ?>
            <div class="product" data-brand="<?php echo $row['brand']; ?>" data-price="<?php echo $row['price']; ?>">
                <img src="uploads/<?php echo $row['img_path_for_motor']; ?>" alt="Motor Image">
                <h3><?php echo $row['brand']; ?></h3>
                <div class="price">₱<?php echo $row['price']; ?></div>
            </div>

            <!-- Product preview -->
            <div class="products-preview">
                <div class="preview" id="p-<?php echo $row['motor_id']; ?>">
                    <i class="fas fa-times"></i>
                    <img src="uploads/<?php echo $row['img_path_for_user']; ?>" alt="User Image">
                    <h3><?php echo $row['driver_firstname'] . ' ' . $row['driver_lastname']; ?></h3>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                        <span>( 250 )</span>
                    </div>
                    <div class="brand"><?php echo $row['brand']; ?></div>
                    <div class="price">₱<?php echo $row['price']; ?></div>
                    <div class="buttons">
                        <a href="booking_form.php" class="buy">BOOK NOW</a> <!-- Changed button class to "book-now" and added onclick event -->
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php
        }
    } else {
        echo "0 results";
    }

    // Close database connection
    $conn->close();
?>


</body>
</html>
