<?php
// Include database connection
include_once 'config.php';

// Check if motor ID is provided in the URL
if(isset($_GET['id'])) {
    $motorId = $_GET['id'];

    // Retrieve motor details from the database based on the provided motor ID
    $stmt = $conn->prepare("SELECT * FROM Motors WHERE motor_id = ?");
    $stmt->bind_param("i", $motorId);
    $stmt->execute();
    $result = $stmt->get_result();
    $motor = $result->fetch_assoc();

    // Check if motor exists
    if($motor) {
        // Display the motor details in a form for updating
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Update Motor</title>
            <!-- Include any CSS stylesheets or frameworks if needed -->
        </head>
        <body>
            <h1>Update Motor</h1>
            <form action="update_process.php" method="POST">
                <!-- Include input fields for updating motor details -->
                <input type="hidden" name="motor_id" value="<?php echo $motor['motor_id']; ?>">
                <label for="brand">Brand:</label>
                <input type="text" id="brand" name="brand" value="<?php echo $motor['brand']; ?>"><br>
                <label for="driver_firstname">Driver's First Name:</label>
                <input type="text" id="driver_firstname" name="driver_firstname" value="<?php echo $motor['driver_firstname']; ?>"><br>
                <label for="driver_lastname">Driver's Last Name:</label>
                <input type="text" id="driver_lastname" name="driver_lastname" value="<?php echo $motor['driver_lastname']; ?>"><br>
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" value="<?php echo $motor['address']; ?>"><br>
                <label for="price">Price:</label>
                <input type="text" id="price" name="price" value="<?php echo $motor['price']; ?>"><br>
                <!-- Add more input fields as needed -->
                <button type="submit">Update Motor</button>
            </form>
        </body>
        </html>

        <?php
    } else {
        echo "Motor not found!";
    }

    // Close statement and database connection
    $stmt->close();
    $conn->close();
} else {
    echo "Motor ID not provided!";
}
?>
