<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Additional Items</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0; /* Light grey background */
        }

        .container {
            display: flex;
            justify-content: center; /* Center content horizontally */
            align-items: center; /* Center content vertically */
            height: 100vh; /* Adjusted to fit viewport height */
        }

        .content {
            background-color: #fff; /* White background */
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3); /* Black box-shadow */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd; /* Light grey border-bottom */
        }

        th {
            background-color: #f2f2f2; /* Light grey background for table header */
        }

        tr:nth-child(even) {
            background-color: #f9f9f9; /* Light grey background for even rows */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <?php
            // Include database connection
            include_once 'config.php';

            // Fetch additional items data from the database
            $sql = "SELECT * FROM AdditionalItems";
            $result = $conn->query($sql);

            // Display table header for additional items
            echo "<h2>Additional Items</h2>";
            echo "<table>";
            echo "<tr><th>Name</th><th>Price</th></tr>";

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>{$row['name']}</td>";
                    echo "<td>{$row['additional_price']}</td>";
                    echo "</tr>";
                }
            } else {
                // If no additional items found, display a message
                echo "<tr>";
                echo "<td colspan='2'>No additional items found.</td>";
                echo "</tr>";
            }
            echo "</table>";

            // Close connection
            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
