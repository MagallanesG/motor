<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #87CEEB; /* Sky Blue */
        }
        .container {
            display: flex;
        }
        .sidebar {
            width: 300px;
            height: 100vh; /* Adjusted to fit the viewport height */
            background-color: #333;
            color: #fff;
            padding: 20px;
            box-sizing: border-box;
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .nav-link {
            display: block;
            color: #fff;
            margin: 80px;
            text-decoration: none;
            margin-bottom: 10px;
        }
        .nav-link:hover {
            background-color: #555;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 5px;
            text-align: center;
        }
        th {
            background-color: #555;
            color: #fff;
            
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        @media screen and (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
            }
        }

        /* Style for the table */


/* Style for the action buttons */
button {
    padding: 5px 10px;
    margin-right: 5px;
    border: none;
    cursor: pointer;
    border-radius: 3px;
}

button i {
    margin-right: 5px;
}

button:hover {
    background-color: #e0e0e0;
}

/* Adjustments for specific buttons */
button.add-button {
    background-color: #4caf50;
    color: white;
}

button.delete-button {
    background-color: #f44336;
    color: white;
}

button.update-button {
    background-color: #2196f3;
    color: white;
}

button.view-button {
    background-color: #ff9800;
    color: white;
}
/* Close button style */
.close-btn1 {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 24px;
    cursor: pointer;
    color: #000;
}

.close-btn1:hover {
    color: #ff0000; /* Change color on hover */
}

.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    display: none;
    justify-content: center;
    align-items: center;
}

.overlay-content {
    background-color: #f9f9f9; /* Grey background */
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    width: 400px;
    max-width: 90%; /* Adjusted to fit smaller screens */
    max-height: 90%; /* Adjusted to fit smaller screens */
    overflow-y: auto; /* Enable vertical scrolling if content overflows */
    display: flex;
    flex-direction: column;
    justify-content: center; /* Center content vertically */
    align-items: center; /* Center content horizontally */
}

.overlay-content label,
.overlay-content input[type="text"],
.overlay-content input[type="file"],
.overlay-content input[type="submit"] {
    margin-bottom: 20px;
}



.fa-times{
   position: absolute;
   top:1rem; right:1.5rem;
   cursor: pointer;
   color:#444;
   font-size: 4rem;
}

.fa-times:hover{
   transform: rotate(90deg);
}
.disabled-row {
        opacity: 0.5; /* Adjust opacity to control the level of disabled appearance */
    }

    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h2>Admin Dashboard</h2>
            <a href="?page=dashboard" class="nav-link">Dashboard</a>
            <a href="?page=users" class="nav-link">Users</a>
            <a href="?page=motors" class="nav-link">Motors</a>
            <a href="?page=reports" class="nav-link">Reports</a>
        </div>
        <div class="content">
        <?php
// Include database connection
include_once 'config.php';

// Check which page is requested
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

// Include the appropriate content based on the page requested
switch ($page) {
    case 'dashboard':
        echo "<h2>Dashboard</h2>";
        echo "<p>Welcome to the admin dashboard.</p>";
        break;
    case 'users':
        echo "<h2>Users</h2>";
        // Display users information
        break;
        case 'motors':
            echo "<h2>Motors</h2>";
            
            // Button for adding additional items
            echo "<button onclick=\"openAddAdditionalForm()\">Add Additional Item</button>";
            
            // Button for viewing additional items
            echo "<button onclick=\"viewAdditionalItems()\">View Additional Items</button>";
            
            // JavaScript function to redirect to view_additional.php
            echo "<script>
                function viewAdditionalItems() {
                    window.location.href = 'view_additional.php';
                }
            </script>";
            
          // Fetch motors data from the database
$sql = "SELECT * FROM Motors";
$result = $conn->query($sql);

// Display table header for motors
echo "<table>";
echo "<tr><th>Motor ID</th><th>Brand</th><th>Driver Firstname</th><th>Driver Lastname</th><th>Price</th><th>Action</th></tr>";

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $motorId = $row['motor_id'];
        $disabledClass = $row['enabled'] ? '' : 'disabled-row'; // Add disabled-row class if the motor is disabled
        
        echo "<tr id='motorRow_{$motorId}' class='{$disabledClass}'>"; // Added unique ID for each row and disabled-row class if needed
        echo "<td>{$row['motor_id']}</td>";
        echo "<td>{$row['brand']}</td>";
        echo "<td>{$row['driver_firstname']}</td>";
        echo "<td>{$row['driver_lastname']}</td>";
        echo "<td>{$row['price']}</td>";
        // Add action buttons for adding, deleting, updating, and viewing functions for each row
        echo "<td>";
        echo "<button onclick=\"addFunction({$motorId})\"><i class='fas fa-plus'></i> Add</button>";
        echo "<button onclick=\"deleteFunction({$motorId})\"><i class='fas fa-trash'></i> Delete</button>";
        echo "<button onclick=\"updateFunction({$motorId})\"><i class='fas fa-edit'></i> Update</button>";
        echo "<button onclick=\"viewFunction({$motorId})\"><i class='fas fa-eye'></i> View</button>";
        // Add button to toggle motor
        echo "<button onclick=\"toggleMotor({$motorId})\"><i class='fas fa-power-off'></i> Toggle</button>";
        echo "</td>";
        echo "</tr>";
    }
} else {
    // If no motors found, display an empty row with action buttons
    echo "<tr>";
    echo "<td colspan='6'>No motors found.</td>";
    echo "<td>";
    echo "<button onclick=\"addFunction(0)\">Add</button>"; // Assuming 0 is a placeholder for adding a new motor
    echo "</td>";
    echo "</tr>";
}
echo "</table>";

            
            // Overlay for adding a new motor
            echo "<div id='overlay' class='overlay' style='display:none;'>";
            echo "<div class='overlay-content'>";
            echo "<span class='close-btn' onclick='closeOverlay()'>&times;</span>";
            echo "<h2>Add Motor</h2>";
            echo "<form id='addMotorForm' action='add_motor.php' method='post' enctype='multipart/form-data'>";
            echo "<label for='brand'>Brand:</label>";
            echo "<input type='text' id='brand' name='brand' required><br>";
            echo "<label for='driver_firstname'>Driver's First Name:</label>";
            echo "<input type='text' id='driver_firstname' name='driver_firstname' required><br>";
            echo "<label for='driver_lastname'>Driver's Last Name:</label>";
            echo "<input type='text' id='driver_lastname' name='driver_lastname' required><br>";
            echo "<label for='address'>Address:</label>";
            echo "<input type='text' id='address' name='address' required><br>";
            echo "<label for='price'>Price:</label>";
            echo "<input type='text' id='price' name='price' required><br>";
            echo "<label for='motor_image'>Motor Image Path:</label>";
            echo "<input type='file' id='img_path_for_motor' name='img_path_for_motor' accept='image/*' required><br>";
            echo "<label for='user_image'>User Image Path:</label>";
            echo "<input type='file' id='img_path_for_user' name='img_path_for_user' accept='image/*' required><br>";
            echo "<input type='submit' value='Add Motor'>";
            echo "</form>";
            echo "</div>";
            echo "</div>";
            
            break;
        
        
      
        case 'reports':
            echo "<h2>Reports</h2>";
            // Display reports information
            break;
    
        default:
            echo "<h2>Page not found</h2>";
            break;
    }
?>
<!-- Overlay for adding additional item -->
<div id="additionalOverlay" class="overlay">
    <div class="overlay-content">
        <span class="close-btn1" onclick="closeAdditionalOverlay()">&times;</span>
        <h2>Add Additional Item</h2>
        <form id="addAdditionalForm" action="add_additional.php" method="post">
            <label for="additional_name">Name:</label>
            <input type="text" id="additional_name" name="additional_name" required><br>
            <label for="additional_price">Price:</label>
            <input type="text" id="additional_price" name="additional_price" required><br>
            <input type="submit" value="Add Additional Item">
        </form>
    </div>
</div>

    <script>
        // Function to open the overlay for adding additional item
        function openAddAdditionalForm() {
            document.getElementById("additionalOverlay").style.display = "flex";
        }

        // Function to close the overlay for adding additional item
        function closeAdditionalOverlay() {
            document.getElementById("additionalOverlay").style.display = "none";
        }
    </script>

<script src="admin.js"></script>

        </div>
    </div>
</body>
</html>
