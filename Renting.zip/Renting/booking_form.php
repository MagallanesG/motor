<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Booking Form</title>
   <style>
      /* CSS for the booking form */
      .booking-form {
         max-width: 400px;
         margin: 0 auto;
         padding: 20px;
         border: 1px solid #ccc;
         border-radius: 5px;
         background-color: #f9f9f9;
      }
      .booking-form h2 {
         text-align: center;
      }
      .booking-form label {
         display: block;
         margin-bottom: 10px;
      }
      .booking-form input[type="text"],
      .booking-form input[type="number"],
      .booking-form input[type="date"] {
         width: 100%;
         padding: 8px;
         margin-bottom: 15px;
         border: 1px solid #ccc;
         border-radius: 3px;
         box-sizing: border-box;
      }
      .booking-form button[type="submit"] {
         width: 100%;
         padding: 10px;
         background-color: #4CAF50;
         color: white;
         border: none;
         border-radius: 3px;
         cursor: pointer;
      }
      .booking-form button[type="submit"]:hover {
         background-color: #45a049;
      }
   </style>
</head>
<body>
   <!-- Booking Form -->
   <div id="bookingForm" class="booking-form">
      <h2>Booking Form</h2>
      <form action="submit_booking.php" method="post" onsubmit="return calculateTotal()">
         <label for="motorBrand">Motor Brand:</label>
         <select id="motorBrand" name="motorBrand" onchange="fetchPrice()">
            <?php
            // Include database configuration file
            include_once 'config.php';

            // Query to fetch motor brands from the motors table
            $sql = "SELECT brand, price FROM motors";
            $result = $conn->query($sql);

            // Check if the query was successful
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['price'] . "'>" . $row['brand'] . "</option>";
                }
            } else {
                echo "<option value='0'>No motors available</option>";
            }
            ?>
         </select>

         <?php
         // Query to fetch additional items from the AdditionalItems table
         $sql = "SELECT name, additional_price FROM AdditionalItems";
         $result = $conn->query($sql);

         // Check if the query was successful
         if ($result->num_rows > 0) {
             while($row = $result->fetch_assoc()) {
                 echo "<label for='additional_" . strtolower($row['name']) . "'>Additional " . $row['name'] . " (+₱" . $row['additional_price'] . "):</label>";
                 echo "<input type='checkbox' id='additional_" . strtolower($row['name']) . "' name='additionalItems[]' value='" . $row['additional_price'] . "' onclick='calculateTotal()'>";
             }
         }
         ?>

         <label for="date">Date:</label>
         <input type="date" id="date" name="date" onchange="calculateTotal()">
         <label for="days" name="days">Number of Days:</label>
         <input type="number" id="days" name="days" min="1" value="1" onchange="calculateTotal()">
         <label for="total" name="total">Total Price:</label>
         <input type="text" id="total" name="total" readonly>
         <button type="submit" name="submit">Submit</button>
      </form>
   </div>
   <script>
      function calculateTotal() {
         console.log("calculateTotal function called");
         var selectedPrice = parseFloat(document.getElementById("motorBrand").value);
         var basePrice = selectedPrice ? selectedPrice : 0; // If a price is selected, use it as the base price, otherwise default to 0
         var additionalItems = document.getElementsByName("additionalItems[]");
         var additionalItemsPrice = 0;

         // Calculate the total price of additional items
         for (var i = 0; i < additionalItems.length; i++) {
            if (additionalItems[i].checked) {
               additionalItemsPrice += parseFloat(additionalItems[i].value);
            }
         }

         var days = parseInt(document.getElementById("days").value);
         var totalPrice = (basePrice  * days) + additionalItemsPrice;
         document.getElementById("total").value = "₱" + totalPrice.toFixed(2);
         return true; // Allow form submission
      }

      function fetchPrice() {
         console.log("fetchPrice function called");
         var selectedPrice = parseFloat(document.getElementById("motorBrand").value);
         document.getElementById("total").value = "₱" + selectedPrice.toFixed(2);
      }
   </script>
</body>
</html>
