document.addEventListener("DOMContentLoaded", function() {
    let next = document.querySelector('.next');
    let prev = document.querySelector('.prev');

    // Function to move to the next slide
    function moveToNextSlide() {
        let items = document.querySelectorAll('.item');
        let lastItem = items[items.length - 1]; // Get the last item
        document.querySelector('.slide').prepend(lastItem); // Move the last item to the beginning
    }

    // Function to move to the previous slide
    function moveToPrevSlide() {
        let items = document.querySelectorAll('.item');
        let firstItem = items[0]; // Get the first item
        document.querySelector('.slide').appendChild(firstItem); // Move the first item to the end
    }

    next.addEventListener('click', moveToNextSlide);

    prev.addEventListener('click', moveToPrevSlide);

    // Event listener for keyboard arrow keys
    document.addEventListener('keydown', function(event) {
        switch(event.key) {
            case 'ArrowLeft':
                moveToPrevSlide(); // Move to previous slide
                break;
            case 'ArrowRight':
                moveToNextSlide(); // Move to next slide
                break;
            default:
                // Do nothing for other keys
        }
    });
});
