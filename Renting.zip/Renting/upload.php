<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
    // Check if file was uploaded without errors
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0) {
        $targetDir = "uploads/"; // Specify the directory where you want to store the uploaded files
        $targetFile = $targetDir . basename($_FILES["file"]["name"]); // Get the file name with extension
        
        // Check if file already exists
        if (file_exists($targetFile)) {
            echo "File already exists.";
        } else {
            // Upload file to the specified directory
            if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
                echo "The file ". htmlspecialchars( basename( $_FILES["file"]["name"])). " has been uploaded.";
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        echo "No file uploaded or an error occurred while uploading.";
    }
} else {
    // Redirect users if they try to access this page directly without submitting the form
    header("Location: index.html");
    exit;
}
?>

