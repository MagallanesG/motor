<?php
// Include the database connection configuration
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login_submit'])) {
    // Retrieve user input from the login form
    $email = $_POST['login_email'];
    $password = $_POST['login_password'];

    // Define admin credentials
$adminEmail = 'admin@example.com';
$adminPasswordHash = '$2y$10$zfXgngrBvX7UC6eK7q13oODEYMoGaDIYaOCz82H8gHSpn0EkDi8LC'; // Replace this with the hashed admin password

// Check if the provided credentials match the admin credentials
if ($email === $adminEmail && password_verify($password, $adminPasswordHash)) {
    // Admin login, redirect to admin page
    session_start();
    $_SESSION['user_id'] = 'admin'; // You can set any unique identifier for admin
    $_SESSION['username'] = 'Admin'; // You can set any name for admin
    header("Location: admin.php");
    exit;
}


    try {
        // Prepare the SQL statement to retrieve user information based on the provided email
        $stmt = $conn->prepare("SELECT * FROM Users WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // If a user with the provided email is found
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verify the password
            if (password_verify($password, $user['PasswordHash'])) {
                // Password is correct, set session variables or perform any other actions for successful login
                session_start();
                $_SESSION['user_id'] = $user['UserID']; // Assuming your user table has a column named 'UserID'
                $_SESSION['username'] = $user['Username']; // Assuming your user table has a column named 'Username'
                // Redirect the user to the dashboard or any other page after successful login
                header("Location: user.html");
                exit;
            } else {
                // Password is incorrect
                echo "Incorrect password. Please try again.";
            }
        } else {
            // No user found with the provided email
            echo "No user found with this email. Please sign up.";
        }
    } catch (mysqli_sql_exception $e) {
        echo "Error: " . $e->getMessage();
    }

    // Close the statement
    $stmt->close();
    // Close the database connection
    $conn->close();
} else {
    // Redirect users if they try to access this page directly without submitting the login form
    header("Location: user.html");
    exit;
}
?>
