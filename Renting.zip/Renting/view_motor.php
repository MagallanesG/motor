<?php
// Include the database connection configuration
require 'config.php';

// Check if a motor ID is provided in the URL
if (isset($_GET['motor_id'])) {
    $motorId = $_GET['motor_id'];

    try {
        // Prepare the SQL statement to retrieve motor details based on the provided ID
        $stmt = $conn->prepare("SELECT * FROM Motors WHERE motor_id = ?");
        $stmt->bind_param("i", $motorId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the motor with the provided ID exists
        if ($result->num_rows === 1) {
            $motor = $result->fetch_assoc();
            // Display the motor details
            ?>
           <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Motor Details</title>
    <style>
    
        body {
            font-family: Arial, sans-serif;
            background-color: skyblue;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        h1 {
            position: absolute;
            top: 1%;
            left: -70%;
            text-align: center;
        }
        .container {
            position: absolute;
            width: 35%;
            height: 90%;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px black;
           
           
        }
      
        .user-info {
            text-align: center;
            margin-bottom: 150px;
        }
        .user-img {
            max-width: 100px;
            height: auto;
            margin: 0 auto;
            display: block;
            border-radius: 50%;
            margin-bottom: 20px;
        }
        .driver-name {
            text-transform: uppercase;
            font-weight: bold;
            font-size: 20px;
            margin-bottom: 10px;
        }
        .driver-address {
            text-transform: uppercase;
            font: italic;
            margin-bottom: 30px;
        }
        .motor-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .motor-img {
            max-width: 140px;
            height: auto;
            margin-right: 50px;
            margin-bottom: 20px;
        }
        .motor-info {
            flex: 1;
            margin-bottom: 20px;
            margin-left: 30px;
            font-size: 18px;
        }
        @media (max-width: 768px) {
            .motor-details {
                flex-direction: column;
            }
            .motor-img {
                margin: 0 auto 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Motor Details</h1>
        <div class="user-info">
    <img class="user-img" src="uploads/<?php echo $motor['img_path_for_user']; ?>" alt="User Image">
    <div class="user-details">
        <div class="driver-name">
            <?php echo $motor['driver_firstname']; ?> <?php echo $motor['driver_lastname']; ?>
        </div>
        <div class="driver-address">
            <?php echo $motor['address']; ?>
        </div>
    </div>
</div>

        <div class="motor-details">
            <div class="motor-info">
                <p><strong>Brand:</strong> <?php echo $motor['brand']; ?></p>
                <p><strong>Price:</strong> <?php echo $motor['price']; ?></p>
            </div>
            <img class="motor-img" src="uploads/<?php echo $motor['img_path_for_motor']; ?>" alt="Motor Image">
        </div>
    </div>
</body>
</html>


            <?php
            exit; // Stop further execution
        } else {
            // Motor with the provided ID does not exist
            echo "Motor not found.";
        }
    } catch (mysqli_sql_exception $e) {
        echo "Error: " . $e->getMessage();
    }

    // Close the statement
    $stmt->close();
    // Close the database connection
    $conn->close();
} else {
    // No motor ID provided in the URL
    echo "No motor ID provided.";
}
?>
